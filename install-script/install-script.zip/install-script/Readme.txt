Steps to setup the system

1) pg-install.sh
2) node-install.sh
3) nginx-install.sh
4) deploy-tls.sh
5) create_user_and_db.sh
6) install-pm2.sh


envs used 
1) updateTicket boolean to enable or disable ticket update. eg.  updateTicket=true/false pm2 restart app --update-env



